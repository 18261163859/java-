package com.study.basicgrammar;

import java.util.Scanner;

public class Assignment02 {
    public static void main(String[] args) {
        /**
         * 2. 定义一个整型变量并赋任意五位正整数作为初始值，输出各位数字之和
         * (例如:12345 各位之和是:1+2+3+4+5 。也就是 15)
         */

        //定义一个整型变量并赋任意五位正整数作为初始值
        System.out.println("请输入任意五位正整数：");
        int inputNumber=new Scanner(System.in).nextInt();

        //拿到个位、万位、十位、千位、百位
        int gewei=inputNumber%10;//个位
        int wanwei=inputNumber/10000;//万位
        int shiwei=inputNumber%100/10;//十位
        int qianwei=inputNumber%10000/1000;//千位
        int baiwei=inputNumber%1000/100;//百位

        //输出各位数字之和
        System.out.println(gewei+shiwei+baiwei+qianwei+wanwei);
    }
}
