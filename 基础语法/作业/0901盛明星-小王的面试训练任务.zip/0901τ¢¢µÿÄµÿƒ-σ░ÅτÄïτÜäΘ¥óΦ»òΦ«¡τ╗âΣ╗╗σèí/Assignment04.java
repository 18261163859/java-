package com.study.basicgrammar;

public class Assignment04 {
    public static void main(String[] args) {
        /**
         * 4. 请写出一段遵守编码规范的 Hello World 代码
         * (注意，注释必须有，也要遵守规范)
         */

        //输出Hello World
        System.out.println("Hello World");
    }
}
