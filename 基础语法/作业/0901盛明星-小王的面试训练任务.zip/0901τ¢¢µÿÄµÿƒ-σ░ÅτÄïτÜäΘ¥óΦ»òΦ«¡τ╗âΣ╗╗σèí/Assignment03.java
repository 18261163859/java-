package com.study.basicgrammar;

public class Assignment03 {
    public static void main(String[] args) {
        /**
         * 定义整型变量 a、b，写出将 a、b 两个变量值进行互换的程序
         * (要求不能使用第三个变量)
         */

        //定义变量
        int a=15;
        int b=20;

        //交换算法
        a=a+b;
        b=a-b;
        a=a-b;

        System.out.println("a:"+a+"____b:"+b);
    }
}
