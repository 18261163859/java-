package com.study.basicgrammar;

import javax.sound.midi.Soundbank;
import java.util.Scanner;

public class Assignment01 {
    public static void main(String[] args) {
        /***
         *1. 定义一个整型变量并赋任意五位正整数作为初始值，判断它是不是五位 回文数
         * (五位回文数:个位与万位相同，十位与千位相同，例如:12321):
         */

        //定义一个整型变量并赋任意五位正整数作为初始值
        System.out.println("请输入任意五位正整数判断是否为五位回文数：");
        int inputNumber=new Scanner(System.in).nextInt();

        //拿到个位、万位、十位、千位
        int gewei=inputNumber%10;//个位
        int wanwei=inputNumber/10000;//万位
        int shiwei=inputNumber%100/10;//十位
        int qianwei=inputNumber%10000/1000;//千位


        //判断并输出是否符合条件
        System.out.println(gewei==wanwei&&shiwei==qianwei);
    }
}
