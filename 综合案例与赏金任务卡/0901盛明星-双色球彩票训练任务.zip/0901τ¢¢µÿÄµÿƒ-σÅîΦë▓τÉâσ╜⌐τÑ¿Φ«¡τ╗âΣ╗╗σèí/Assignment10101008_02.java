package com.shengmingxing;

import java.util.Random;
import java.util.Scanner;

//双色球彩票训练任务
public class Assignment10101008_02 {
    public static void main(String[] args) {
        //生成6红1蓝
        int[] redNumsRandom=new int[6];
        int blueNumRandom;

        for (int i = 0; i < 6; i++) {
            int midNum=(int)(Math.random()*32)+1;
            while(checkInclude(midNum,redNumsRandom)==1){
                midNum=(int)(Math.random()*32)+1;
            }
            redNumsRandom[i]=midNum;
        }
        blueNumRandom=(int)(Math.random()*15)+1;

        System.out.print("红：");
        for (int item : redNumsRandom) {
            System.out.print(item+",");
        }
        System.out.println("蓝："+blueNumRandom);

        //输入6红1蓝
        Scanner scanner=new Scanner(System.in);
        int[] redNums=new int[6];
        int blueNum;
        System.out.println("请输入6个不重复红色球数字（1-33）：");
        for (int j = 0; j < redNums.length; j++) {
            redNums[j]=scanner.nextInt();
        }
        System.out.println("请输入1个蓝色球数字：");
        blueNum=scanner.nextInt();

        int blueWinNumberCount=0;
        int redWinNumberCount=0;
        //遍历查找中奖号码
        for (int item : redNums) {
            redWinNumberCount+=checkInclude(item,redNumsRandom);
        }
        if(blueNum==blueNumRandom) blueWinNumberCount=1;


        int total=redWinNumberCount+blueWinNumberCount;
        switch (total){
            case 7:{System.out.println("一等奖");}break;
            case 6:{if(blueWinNumberCount==0) System.out.println("二等奖");
            else System.out.println("三等奖");}break;
            case 5:{
                System.out.println("四等奖");
            }break;
            case 4:{
                System.out.println("五等奖");
            }break;
            case 3: case 2: case 1:{
                System.out.println("六等奖");
            }
        }



    }

    /**
     * 检查一个数是否包含在一个数组里
     * @param num  查检的数字
     * @param nums 遍历的数组
     * @return 包含返回1 不包含返回0
     */
    public static int checkInclude(int num,int[] nums){
        int[] checkNums=new int[6];
        for (int i = 0; i < nums.length; i++) {
            checkNums[i]=nums[i];
        }
        //冒泡排序
        for (int i = 0; i < checkNums.length-1; i++) {
            for (int j = 0; j < checkNums.length-i-1; j++) {
                if(checkNums[j]>checkNums[j+1]){
                    int temp=checkNums[j];
                    checkNums[j]=checkNums[j+1];
                    checkNums[j+1]=temp;
                }
            }
        }

        //折半查找法
        int maxIndex=checkNums.length;
        int minIndex=0;
        int midIndex=(maxIndex+minIndex)/2;
        while(true){
            if(checkNums[midIndex]<num){
                minIndex=midIndex+1;
            }
            else if(checkNums[midIndex]>num){
                maxIndex=midIndex-1;
            }
            else
            {
                return 1;
            }
            if(maxIndex<minIndex) return 0;
            midIndex=(maxIndex+minIndex)/2;
            if(midIndex>checkNums.length-1) return 0;
        }

    }
}
