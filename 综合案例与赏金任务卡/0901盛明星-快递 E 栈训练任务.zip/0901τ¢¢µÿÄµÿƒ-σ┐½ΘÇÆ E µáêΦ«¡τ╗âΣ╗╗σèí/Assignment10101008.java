package com.shengmingxing;

import java.util.Random;
import java.util.Scanner;

//快递E栈训练任务
public class Assignment10101008 {
    public static void main(String[] args) {



        //定义变量
        int adminOperation,userOperation;
        String trackingNumber,corporationName,fetchNumber;
        int arrSize=0;
        String[][] strs=new String[arrSize][3];

        Scanner scanner=new Scanner(System.in);

        while (true){
            System.out.println("=====欢迎使用新职课快递柜=====");
            //输入信息
            System.out.println("请输入您的身份：1-快递员，2-用户");
            int identity = scanner.nextInt();

            //快递员
            if(identity==1){
                System.out.println("请选择操作：1-存快递 2-删除快递 3-修改快递信息 4-查看所有快递");
                adminOperation=scanner.nextInt();
                //存快递
                if(adminOperation==1){
                    arrSize+=1;
                    //定义新数组
                    String[][] newStrs=new String[arrSize][3];
                    for (int i = 0; i < strs.length; i++) {
                        newStrs[i+1]=strs[i];
                    }

                    System.out.println("请输入快递单号");
                    trackingNumber=scanner.next();
                    System.out.println("请输入公司名称");
                    corporationName= scanner.next();
                    fetchNumber=String.valueOf(new Random().nextInt(900)+100);
                    System.out.println("快递已存入，取件码是："+fetchNumber);

                    //存入新数组
                    newStrs[0][0]=trackingNumber;
                    newStrs[0][1]=corporationName;
                    newStrs[0][2]=fetchNumber;

                    //赋值原数组
                    strs=newStrs;



                }
                //删除快递
                else if(adminOperation==2){
                    System.out.println("请输入要删除的快递单号：");
                    String delTrackingNumber=scanner.next();

                    int status=0;
                    //赋值新数组
                    for (int i=0;i<strs.length;i++) {
                        if(strs[i][0].equals(delTrackingNumber)){
                            status=1;
                        }
                    }
                    if(status==0){
                        System.out.println("未找到该快递");

                    }
                    else{
                        System.out.println("删除成功！");
                        String[][] newStrs=new String[--arrSize][3];
                        if(strs.length>1) for (int i = 0; i < strs.length; i++) {
                            if (!strs[i][2].equals(delTrackingNumber)) {
                                if (status == 0)
                                    newStrs[i] = strs[i];
                                else
                                    newStrs[i - 1] = strs[i];
                            }
                        }

                        strs=newStrs;
                    }

                }
                //修改快递信息
                else if(adminOperation==3){
                    System.out.println("请输入要修改的快递单号：");
                    String modifyTrackingNumber=scanner.next();
                    int status=0;

                    for (int i = 0; i < strs.length; i++) {
                        if(strs[i][0].equals(modifyTrackingNumber)){
                            status=1;
                            System.out.println("请输入新的快递单号：");
                            strs[i][0]=scanner.next();
                            System.out.println("请输入新的公司名称：");
                            strs[i][1]=scanner.next();
                        }
                    }

                    if(status==0){
                        System.out.println("未找到快递");
                    }

                }
                //查看所有快递
                else if(adminOperation==4){
                    //查看所有快递
                    System.out.println("所有快递信息如下：");
                    System.out.printf("快递单号\t");
                    System.out.printf("公司名称\t");
                    System.out.printf("取件码\t");
                    System.out.println();
                    for (String[] item : strs) {
                        for (String s : item) {
                            System.out.printf(s+"\t");
                        }
                        System.out.println();
                    }
                }
            }
            //用户取件
            else if(identity==2){
                int status=0;
                //定义新数组

                System.out.println("请输入取件码：");
                fetchNumber=scanner.next();
                for (int i = 0; i < strs.length; i++) {
                    if(strs[i][2].equals(fetchNumber)){
                        status=1;
                    }

                }

                if(status==0){
                    System.out.println("未找到该快递");

                }
                else{
                    System.out.println("取件成功！");
                    String[][] newStrs=new String[--arrSize][3];
                    if(strs.length>1) for (int i = 0; i < strs.length; i++) {
                        if (!strs[i][2].equals(fetchNumber)) {
                            if (status == 0)
                                newStrs[i] = strs[i];
                            else
                                newStrs[i - 1] = strs[i];
                        }
                    }

                    strs=newStrs;
                }
            }
        }

    }
}
